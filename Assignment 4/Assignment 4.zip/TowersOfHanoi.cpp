#include <iostream>
#include "TowersOfHanoi.h"
using namespace std;

/* Constant: kPauseTime
 *
 * Amount of time to pause for when beginning the Towers Of Hanoi animation.
 */
const double kPauseTime = 500;

/* This function is adapted from the one in Chapter 8.1 of the textbook. If you
 * haven't yet read that chapter, I recommend that you do so before starting
 * this problem.
 */
void moveTower(int numDisks, char start, char finish, char temp, int& totalMoves) {
    if (numDisks != 0) {
        moveTower(numDisks - 1, start, temp, finish, totalMoves);
        moveSingleDisk(start, finish);
        totalMoves++;
        moveTower(numDisks - 1, temp, finish, start, totalMoves);
    }
}
//numdisks 表示需要移动的盘子数量
//start表示起始柱子
//finish表示目标柱子
//temp表示中间柱子

//调用栈问题：
/*
    如果主函数调用solveTowersOfHanoi，调用栈就会是这样的：
    moveTower(...)
    solveTowersOfHanoi(...)
    main(...)

    递归调用会加深调用栈，直到numDisks为0，然后逐层返回，直到返回到主函数。
*/


//解决n个盘子的汉诺塔问题，需要移动的次数是2^n-1
//实际上是A(n) = A(n-1) + 1 + A(n-1) = 2A(n-1) + 1
//解的形式是A(n) = 2^n - 1
//Big-O notation：O(2^n) 指数级别的时间复杂度

//Q4：变量 totalMoves 在第一次递归子调用之后的第一个 moveTower 调用中的值是多少？
//A4：0->1 是1

int solveTowersOfHanoi(int numDisks, char start, char finish, char temp) {
    /* Want to slow this down? Try these other options for the final parameter:
     *
     *   AnimationSpeed::MOLASSES         (extremely slow)
     *   AnimationSpeed::CHEETAH          (regular)
     *   AnimationSpeed::PEREGRINE_FALCON (extremely fast)
     */
    initHanoiDisplay(numDisks, AnimationSpeed::CHEETAH);
    pause(kPauseTime);

    int totalMoves = 0;
    moveTower(numDisks, start, finish, temp, totalMoves);
    return totalMoves;
}
